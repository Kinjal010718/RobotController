﻿using RobotControl.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RobotControl.Commands
{
    class ConsoleCommand
    {
        public static RobotCommand robot;
        public void SetGrid(out int gridWidth, out int gridHeight)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("############################ REALGY'S ROBOT ##########################");

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nEnter the size of the the movement grid. (Formula = X,Y):");
            Console.ForegroundColor = ConsoleColor.DarkCyan;

            string gridArea = Console.ReadLine();
            string[] splitGridArea = gridArea.Split(',');

            while (splitGridArea.Length != 2)
            {
                ShowError("Error: Invalid number of arguments Try again with the Formula = X,Y.", out gridArea, out splitGridArea);
            }

            while (!int.TryParse(splitGridArea[0].Trim(), out gridWidth) || gridWidth <= 0)
            {
                ShowError("Error: Invalid grid width value! Try again with a integer number bigger than zero.", out gridArea, out splitGridArea);
            }

            while (!int.TryParse(splitGridArea[1].Trim(), out gridHeight) || gridHeight <= 0)
            {
                ShowError("Error: Invalid grid height value! Try again with a integer number bigger than zero.", out gridArea, out splitGridArea);
            }

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"\n############################### GRID = {gridWidth}x{gridHeight} ###############################");

        }
        public void ShowMovement(int gridWidth, int gridHeight, int obX, int obY, int obstacle, int spinAmt)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nEnter the movement string. Multiple characters required (e.g. LFFFRFFLFFFFRLFFFR).");
            Console.WriteLine(" -> L = Rotate left");
            Console.WriteLine(" -> R = Rotate right");
            Console.WriteLine(" -> F = Move ahead");
            Console.ForegroundColor = ConsoleColor.DarkCyan;

            string movementString = Console.ReadLine();
            ObstacleCommand obs = new ObstacleCommand(obX, obY, obstacle, robot.position.facingDirection);

            bool flg = true;
            foreach (char c in movementString.ToUpperInvariant())
            {
                if(flg)
                { 
                Thread.Sleep(500);
                    switch (c)
                    {
                        case (char)Direction.Left:
                            robot.rotateLeft();
                            break;
                        case (char)Direction.Right:
                            robot.rotateRight();
                            break;
                        case (char)Direction.Forward:
                            if (obX == robot.position.xPosition && obY == robot.position.yPosition && (Enum.IsDefined(typeof(ObstacleEnum), obstacle) && obstacle != (int)ObstacleEnum.NONE))
                            {
                                obs.obsAction(spinAmt);
                                robot.position.xPosition = obs.robo.position.xPosition;
                                robot.position.yPosition = obs.robo.position.yPosition;
                                robot.position.facingDirection = obs.robo.position.facingDirection;
                                if (obstacle == (int)ObstacleEnum.HOLE)
                                    flg = false;
                            }
                            else
                            {
                                robot.moveForward(gridWidth, gridHeight);
                            }
                            break;
                        default:
                            Console.WriteLine("Invalid character. Ignoring... ");
                            break;
                    }                   
                }

                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("Robot current position:" + robot.AtributesToString());
                if(!flg)
                    break;
            }

        }
        public  void ShowInitialPosition(out int initialX, out int initialY, out char initialDirection)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nEnter the intial robot X position, Y position and the facing direction direction (Formula = X,Y,Direction):");
            Console.WriteLine(" -> X and Y must be a positive integer number smaller than the grid width.");
            Console.WriteLine(" -> Direction N = North");
            Console.WriteLine(" -> Direction S = South");
            Console.WriteLine(" -> Direction E = East");
            Console.WriteLine(" -> Direction W = West.");
            Console.ForegroundColor = ConsoleColor.DarkCyan;

            string initialPosition = Console.ReadLine();
            string[] splitInitialPosition = initialPosition.Split(',');

            while (splitInitialPosition.Length != 3)
            {
                ShowError("Error: Invalid number of arguments. Try again with the Formula = X,Y,Direction.", out initialPosition, out splitInitialPosition);
            }

            while (!int.TryParse(splitInitialPosition[0].Trim(), out initialX) || initialX < 0)
            {
                ShowError("Error: Invalid initial X Position! Try again with a positive integer number.", out initialPosition, out splitInitialPosition);
            }

            while (!int.TryParse(splitInitialPosition[1].Trim(), out initialY) || initialY < 0)
            {
                ShowError("Error: Invalid initial X Position! Try again with a positive integer number.", out initialPosition, out splitInitialPosition);
            }

            initialDirection = char.Parse(splitInitialPosition[2].Trim());
            while (Char.IsNumber(initialDirection) && initialDirection != (char)Orientation.South && initialDirection != (char)Orientation.North && initialDirection != (char)Orientation.East && initialDirection != (char)Orientation.West)
                {
                ShowError("Error: Invalid operation type! Try again with a valid option.", out initialPosition, out splitInitialPosition);
                initialDirection = char.Parse(splitInitialPosition[2].Trim());
            }

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"\n############################### ###############################");

            robot = new RobotCommand(initialX, initialY, initialDirection);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("New robot initialized with values:" + robot.AtributesToString());

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"\n############################### Obstacles ###############################");


        }
        public  void ShowObstaclePosition(out int obX, out int obY, out int obstacle, out int spinAmt)
        {
            spinAmt = 0;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nEnter the obstacle X position, Y position and the obstacle (Formula = X,Y,Obstacle OR 0):");
            Console.WriteLine(" -> X and Y must be a positive integer number smaller than the grid width.");
            Console.WriteLine(" -> 1 = ROCK: Can't move to this location");
            Console.WriteLine(" -> 2 = HOLE: The robot will fall into the hole and end up at the connected location (0,0) and facing same direction");
            Console.WriteLine(" -> 3 = SPIN: The robot will enter the location and be rotated by the parameter amount.  The amount will be in 90 degree increments");
            Console.WriteLine(" -> 0 = NONE: To not set any obstacle or skip this");

            Console.ForegroundColor = ConsoleColor.DarkCyan;

            string obstaclePosition = Console.ReadLine();
            string[] splitObPosition = obstaclePosition.Split(',');

            while (splitObPosition.Length != 3 && !(splitObPosition.Length == 1 && splitObPosition[0] == "0"))
            {
                ShowError("Error: Invalid number of arguments. Try again with the Formula = X,Y,Obstacle OR 0.", out obstaclePosition, out splitObPosition);
                
            }

            if ((splitObPosition.Length == 1 && splitObPosition[0] == "0"))
            {
                obX = obY = 0;
                obstacle = (int)ObstacleEnum.NONE;
            }
            else
            {
                while (!int.TryParse(splitObPosition[0].Trim(), out obX) || obX < 0)
                {
                    ShowError("Error: Invalid initial X Position! Try again with a positive integer number.", out obstaclePosition, out splitObPosition);
                }

                while (!int.TryParse(splitObPosition[1].Trim(), out obY) || obY < 0)
                {
                    ShowError("Error: Invalid initial X Position! Try again with a positive integer number.", out obstaclePosition, out splitObPosition);
                }

                while (!int.TryParse(splitObPosition[2].Trim(), out obstacle) || !Enum.IsDefined(typeof(ObstacleEnum), obstacle))
                {
                    ShowError("Error: Invalid obstacle type! Try again with a valid option (0,1,2 or 3).", out obstaclePosition, out splitObPosition);
                }

                if (obstacle == (int)ObstacleEnum.SPIN)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("\nEnter the amount of rotation (The amount will be in 90 degree increments) : N");
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    string spinValue = Console.ReadLine();
                    while (!int.TryParse(spinValue, out spinAmt) || spinAmt % 90 != 0)
                    {
                        ShowError("Error: Invalid amount N! Amount should be 90 degree increments.", out spinValue, out string[] str);
                    }
                }
            }

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"\n############################### ###############################");

        }
        private static void ShowError(string errorMessage, out string inputVal, out string[] inputArr)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(errorMessage);
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            inputVal = Console.ReadLine();
            inputArr = inputVal.Split(',');
        }
        public  void ShowFinalResult()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("\n ####################################################################################");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n Robot final position:" + robot.AtributesToString());
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("\n ####################################################################################");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n Do you want to initialize a robot? \n  Y - Yes\n  Any other key - Exit");

        }
    }
}
