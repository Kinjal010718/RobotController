﻿using RobotControl.Common;
using RobotControl.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace RobotControl
{
    class ObstacleCommand 
    {
        #region Constructor
        public int obstacleOpt;
        public RobotCommand robo;
        public ObstacleCommand(int xObstacle, int yObstacle, int obstacleOpt, char facingDirection)
        {
            this.obstacleOpt = obstacleOpt;
            robo = new RobotCommand(xObstacle, yObstacle, facingDirection);
        }
        #endregion

        #region public methods
        public void obsAction(int spinAmt = 0)
        {
            switch (obstacleOpt)
            {                
                case (int)ObstacleEnum.HOLE:
                    obstacleHole();
                    break;
                case (int)ObstacleEnum.SPIN:
                    obstacleSpinner(spinAmt);
                    break;
                case (int)ObstacleEnum.ROCK:
                    break;
                default:
                    break;
            }
        }
        public void obstacleHole()
        {
            robo.position.xPosition = 0;
            robo.position.yPosition = 0;
        }
        public void obstacleSpinner(int spinAmt = 0)
        {            
            int diff = spinAmt / 90;
            if (diff > 0)
            {
                for (int i = 0; i < diff; i++)
                {                   
                    robo.rotateRight();
                }
            }
            spinAmt = 0;
        }
        #endregion
    }
}
