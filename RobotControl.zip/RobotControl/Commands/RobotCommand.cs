﻿using RobotControl.Common;
using RobotControl.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotControl
{
    class RobotCommand
    {
        #region Constructor
        public Position position;

        public RobotCommand() { }
        public RobotCommand(int xPosition, int yPosition, char facingDirection)
        {
            position = new Position(xPosition, yPosition, facingDirection);
        }
        #endregion

        #region Public Methods
        public void moveForward(int width, int height)
        {
            switch (position.facingDirection)
            {
                case (char)Orientation.North:
                    if (position.yPosition < height)
                        position.yPosition++;
                    break;

                case (char)Orientation.South:
                    if (position.yPosition > 0)
                        position.yPosition--;
                    break;

                case (char)Orientation.East:
                    if (position.xPosition < width)
                        position.xPosition++;
                    break;

                case (char)Orientation.West:
                    if (position.xPosition > 0)
                        position.xPosition--;
                    break;

            }
        }

        public void rotateLeft()
        {
            switch (position.facingDirection)
            {
                case (char)Orientation.North:
                    position.facingDirection = (char)Orientation.West;
                    break;

                case (char)Orientation.South:
                    position.facingDirection = (char)Orientation.East;
                    break;

                case (char)Orientation.East:
                    position.facingDirection = (char)Orientation.North;
                    break;

                case (char)Orientation.West:
                    position.facingDirection = (char)Orientation.South;
                    break;
            }
        }

        public void rotateRight()
        {
            switch (position.facingDirection)
            {
                case (char)Orientation.North:
                    position.facingDirection = (char)Orientation.East;
                    break;

                case (char)Orientation.South:
                    position.facingDirection = (char)Orientation.West;
                    break;

                case (char)Orientation.East:
                    position.facingDirection = (char)Orientation.South;
                    break;

                case (char)Orientation.West:
                    position.facingDirection = (char)Orientation.North;
                    break;
            }
        }

        public string AtributesToString()
        {
            return $"{position.xPosition},{position.yPosition},{position.facingDirection}";
        }
        #endregion
    }
}
