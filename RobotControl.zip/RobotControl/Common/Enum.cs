﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotControl.Common
{
    public enum ObstacleEnum
    {
        NONE = 0,
        ROCK = 1,
        HOLE = 2,
        SPIN = 3
    }
    public enum Orientation
    {
        North = 'N',
        South = 'S',
        East = 'E',
        West = 'W'
    }
    public enum Direction
    {
        Left = 'L',
        Right = 'R',
        Forward = 'F'
    }
}
