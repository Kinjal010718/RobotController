﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotControl.Entities
{
    public struct Position
    {
        public int xPosition { get; set; }
        public int yPosition { get; set; }
        public char facingDirection { get; set; }
        public Position(int xPosition, int yPosition, char facingDirection)
        {
            this.xPosition = xPosition;
            this.yPosition = yPosition;
            this.facingDirection = facingDirection;
        }
    }
}
