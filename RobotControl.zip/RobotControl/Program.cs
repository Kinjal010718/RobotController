﻿using RobotControl.Commands;
using RobotControl.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RobotControl
{
    class Program
    {
        
        public static void Main()
        {
            while (true)
            {
                Console.Clear();
                ConsoleCommand consoleCmd = new ConsoleCommand();

                //Set Dynamic Grid
                consoleCmd.SetGrid(out int gridWidth, out int gridHeight);

                //Initialize postion of robot
                consoleCmd.ShowInitialPosition(out int initialX, out int initialY, out char initialDirection);

                //Set Obstacles
                consoleCmd.ShowObstaclePosition(out int obX, out int obY, out int obstacle, out int spinAmt);

                //Movement of robot
                consoleCmd.ShowMovement(gridWidth, gridHeight, obX, obY, obstacle, spinAmt);

                //Final result
                consoleCmd.ShowFinalResult();

                if (Console.ReadLine().ToUpperInvariant() != "Y")
                    break;
            }
        }

    }
}
